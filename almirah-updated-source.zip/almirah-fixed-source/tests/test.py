import json
from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={"width":400,"height":800})
    pg.on("pageerror",lambda e:errs.append("PAGEERR "+str(e)))
    pg.on("console",lambda m: errs.append("CONSOLE "+m.text) if m.type=="error" else None)
    pg.goto("file:///home/claude/almirah-app/index.html")
    A=lambda js: pg.evaluate(js)
    print("gs1 paren", A("Almirah.parseGS1('(01)08901234567890(17)271231(10)B123')"))
    print("gs1 raw", A("Almirah.parseGS1('01089012345678901727123110ABC123')"))
    print("gs1 raw GS", A("Almirah.parseGS1('0108901234567890'+'10AB12'+String.fromCharCode(29)+'17271231')"))
    print("gs1 ean", A("Almirah.parseGS1('8901234567890')"))
    txt="PARACETAMOL TABLETS IP 500 mg\\nB.No. PT2301 Mfg 08/2025 Exp 07/2027\\nStrip of 10 tablets\\nMRP Rs 20"
    print("ocr", A("Almirah.parseLabelText('%s')"%txt))
    print("ocr2", A("Almirah.parseLabelText('Cetirizine 10mg\\nEXP: AUG 2028\\nMfg Aug 2025')"))
    # add via UI
    pg.click("button[data-tab=add]")
    pg.fill("#fName","Paracetamol"); pg.fill("#fStrength","500 mg"); pg.fill("#fExpiry","2027-07"); pg.fill("#fQty","10")
    pg.click("#btnSave")
    pg.click("button[data-tab=add]")
    pg.fill("#fName","Cetirizine"); pg.fill("#fStrength","10 mg"); pg.fill("#fExpiry","2026-10"); pg.fill("#fBarcode","8901111111111")
    pg.click("#btnSave")
    pg.click("button[data-tab=add]")
    pg.fill("#fName","Old Syrup"); pg.fill("#fExpiry","2025-01")
    pg.click("#btnSave")
    # duplicate flow
    pg.once("dialog",lambda d:(print("dialog:",d.message),d.accept()))
    pg.click("button[data-tab=add]")
    pg.fill("#fName","paracetamol"); pg.fill("#fStrength","500mg"); pg.fill("#fExpiry","2028-01")
    pg.click("#btnSave")
    s=A("Almirah.state().items.map(i=>[i.name,i.expiry])")
    print("items",s)
    print("stats", pg.inner_text("#stTotal"), pg.inner_text("#stSoon"), pg.inner_text("#stExp"))
    print("banner", pg.inner_text("#banner"))
    print("cards", pg.locator("#list .card").count(), [x for x in pg.locator("#list .card h3").all_inner_texts()])
    print("dup tags", pg.locator("#list .tag", has_text="Duplicate").count())
    # barcode known flow
    pg.evaluate("Almirah.handleCode('8901111111111','add')")
    print("known fill", pg.input_value("#fName"), pg.input_value("#fStrength"))
    pg.click("#btnCancel")
    # buy check
    pg.click("button[data-tab=buy]"); pg.fill("#buyQ","paracetamol")
    print("buy:", pg.inner_text("#buyOut").replace("\n"," | "))
    # xss
    pg.click("button[data-tab=add]"); pg.fill("#fName","<img src=x onerror=window.__x=1>"); pg.click("#btnSave")
    print("xss executed:", A("window.__x===1"))
    # lang
    pg.select_option("#langSel","te"); print("te tab:", pg.inner_text("button[data-tab=cabinet]"))
    pg.select_option("#langSel","hi"); print("hi tab:", pg.inner_text("button[data-tab=add]"))
    pg.select_option("#langSel","en")
    # reload persistence
    pg.reload(); print("persist after reload:", pg.inner_text("#stTotal"))
    # scanner without camera
    pg.click("button[data-tab=add]"); pg.click("#btnBarcode"); pg.wait_for_timeout(500)
    print("scan msg:", pg.inner_text("#scanMsg")); pg.click("#scanClose")
    pg.screenshot(path="/tmp/claude-0/-home-claude/f01ba4a4-fe36-5795-ba8e-16efdbbbafb5/scratchpad/shot.png")
    b.close()
print("ERRORS:",errs)
