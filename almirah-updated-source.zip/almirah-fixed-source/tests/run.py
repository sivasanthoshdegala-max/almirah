import subprocess,time,tempfile,os
from playwright.sync_api import sync_playwright
d=tempfile.mkdtemp(); subprocess.run(["unzip","-q","/home/claude/almirah-app.zip","-d",d])
srv=subprocess.Popen(["python3","-m","http.server","8123","--directory",d+"/almirah-app"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
out="/tmp/claude-0/-home-claude/f01ba4a4-fe36-5795-ba8e-16efdbbbafb5/scratchpad/"
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=["--use-fake-ui-for-media-stream","--use-fake-device-for-media-stream"])
    ctx=b.new_context(viewport={"width":400,"height":800},permissions=["camera"])
    pg=ctx.new_page(); pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.goto("http://localhost:8123/index.html")
    for n,(nm,exp) in enumerate([("Paracetamol","2027-07"),("Cetirizine","2026-10"),("Old Syrup","2025-01")]):
        pg.click("button[data-tab=add]"); pg.fill("#fName",nm); pg.fill("#fExpiry",exp); pg.click("#btnSave")
    pg.screenshot(path=out+"cabinet.png")
    pg.click("button[data-tab=add]"); pg.click("#btnBarcode"); pg.wait_for_timeout(1500)
    print("camera overlay msg:",pg.inner_text("#scanMsg")); pg.screenshot(path=out+"scan.png"); pg.click("#scanClose")
    pg.click("#btnOcr"); pg.wait_for_timeout(1500); print("ocr msg:",pg.inner_text("#scanMsg")); pg.click("#scanClose")
    b.close()
srv.terminate(); print("errors:",errs)
