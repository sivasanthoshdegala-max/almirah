from playwright.sync_api import sync_playwright
import subprocess,time
srv=subprocess.Popen(["python3","-m","http.server","8124","--directory","/home/claude/almirah-app"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch()
    # 1) camera permission denied
    ctx=b.new_context(viewport={"width":400,"height":800}); pg=ctx.new_page(); pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.add_init_script("navigator.mediaDevices.getUserMedia=()=>Promise.reject(Object.assign(new Error('x'),{name:'NotAllowedError'}))")
    pg.goto("http://localhost:8124/index.html"); pg.click("button[data-tab=add]"); pg.click("#btnBarcode"); pg.wait_for_timeout(500)
    print("denied msg:",pg.inner_text("#scanMsg")); print("photo btn visible:",pg.is_visible("#scanPhoto"))
    with pg.expect_file_chooser() as fc: pg.click("#scanPhoto")
    print("file chooser opened:",fc.value is not None)
    # feed an image with text -> OCR path needs internet, so just check flow reaches busy/lib msg
    ctx.close()
    # 2) insecure context (non-localhost http via 127.0.0.1 is secure; simulate)
    ctx=b.new_context(viewport={"width":400,"height":800}); pg=ctx.new_page()
    pg.add_init_script("Object.defineProperty(window,'isSecureContext',{get:()=>false})")
    pg.goto("http://localhost:8124/index.html"); pg.click("button[data-tab=add]"); pg.click("#btnOcr"); pg.wait_for_timeout(300)
    print("insecure msg:",pg.inner_text("#scanMsg")); print("photo btn:",pg.is_visible("#scanPhoto"),"capture hidden:",not pg.is_visible("#ocrShoot"))
    pg.click("#scanClose")
    # 3) buy tab photo button
    pg.click("button[data-tab=buy]")
    with pg.expect_file_chooser() as fc: pg.click("#buyPhoto")
    print("buy photo chooser:",fc.value is not None)
    ctx.close(); b.close()
srv.terminate(); print("errors:",errs)
