from playwright.sync_api import sync_playwright
import datetime
errs=[]; ok=lambda n,c: print(("PASS " if c else "FAIL ")+n)
with sync_playwright() as p:
    b=p.chromium.launch()
    ctx=b.new_context(viewport={"width":400,"height":800},timezone_id="Asia/Kolkata")
    pg=ctx.new_page(); pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.add_init_script("""window.__notes=[];window.Notification=function(t,o){window.__notes.push([t,o&&o.body]);this.close=()=>{}};Notification.permission='granted';Notification.requestPermission=()=>Promise.resolve('granted');""")
    t0=datetime.datetime(2026,10,13,7,58,0,tzinfo=datetime.timezone(datetime.timedelta(hours=5,minutes=30)))
    pg.clock.install(time=t0)
    pg.goto("file:///home/claude/almirah-app/index.html")
    ok("Today tab is default", pg.is_visible("#tab-today"))
    ok("empty state", "No reminders" in pg.inner_text("#todayList"))
    # add medicine with reminder 08:00 and 20:00
    pg.click("button[data-tab=add]"); pg.fill("#fName","Paracetamol"); pg.fill("#fStrength","500 mg"); pg.fill("#fQty","10"); pg.fill("#fExpiry","2027-07")
    pg.check("#fRemOn"); ok("reminder box shown", pg.is_visible("#remBox"))
    pg.click("#remBox .chip[data-t='08:00']"); pg.fill("#fTimeNew","20:00"); pg.click("#btnAddTime")
    ok("2 times chosen", pg.locator("#timeList .tag").count()==2)
    pg.uncheck("#day0")  # not Sundays
    pg.click("#btnSave")
    it=pg.evaluate("Almirah.state().items[0].schedule"); print("schedule",it)
    ok("saved schedule", it["times"]==["08:00","20:00"] and 0 not in it["days"] and it["perDose"]==1)
    # validation: reminder on, no times
    pg.click("button[data-tab=add]"); pg.fill("#fName","X"); pg.check("#fRemOn"); pg.click("#btnSave")
    ok("needs a time", pg.evaluate("Almirah.state().items.length")==1); pg.click("#btnCancel")
    pg.click("button[data-tab=today]")
    ok("today shows 08:00 upcoming", "08:00" in pg.inner_text("#todayList") and "Upcoming" in pg.inner_text("#todayList"))
    ok("summary next", "Next: Paracetamol at 08:00" in pg.inner_text("#todaySummary"))
    ok("no sheet before time", not pg.is_visible("#dueSheet"))
    pg.clock.run_for(3*60*1000)   # 08:01
    ok("sheet appears at dose time", pg.is_visible("#dueSheet"))
    print("notes",pg.evaluate("window.__notes")); ok("notification fired once", len(pg.evaluate("window.__notes"))==1)
    ok("title changed", "Time for" in pg.title())
    # snooze
    pg.click("#dueSheet >> text=Snooze 10 min"); ok("sheet hidden after snooze", not pg.is_visible("#dueSheet"))
    ok("today says snoozed", "Snoozed until" in pg.inner_text("#todayList"))
    pg.clock.run_for(9*60*1000); ok("still hidden before snooze ends", not pg.is_visible("#dueSheet"))
    pg.clock.run_for(2*60*1000); ok("sheet returns after snooze", pg.is_visible("#dueSheet"))
    ok("second notification", len(pg.evaluate("window.__notes"))==2)
    # taken -> qty decrease
    pg.click("#dueSheet >> text=Taken"); ok("sheet closed", not pg.is_visible("#dueSheet"))
    ok("qty 10 -> 9", pg.evaluate("Almirah.state().items[0].qty")==9)
    ok("today shows Taken", "Taken" in pg.inner_text("#todayList"))
    # undo
    pg.click("#todayList >> text=Undo"); ok("undo restores qty", pg.evaluate("Almirah.state().items[0].qty")==10)
    # skip then ensure no qty change
    pg.click("#todayList >> text=Skip"); ok("skip keeps qty", pg.evaluate("Almirah.state().items[0].qty")==10 and "Skipped" in pg.inner_text("#todayList"))
    # missed after >2h (no alert after 3h)
    pg.clock.run_for(4*3600*1000)   # ~12:15
    n_before=len(pg.evaluate("window.__notes"))
    pg.click("#todayList >> text=Undo")  # undo skip of 08:00, now missed
    ok("08:00 shows Missed", "Missed" in pg.inner_text("#todayList"))
    ok("no late notification for old dose", len(pg.evaluate("window.__notes"))==n_before)
    pg.clock.run_for(8*3600*1000+10*60*1000)  # ~20:25 -> 20:00 dose, within 3h? alert at 20:00
    ok("20:00 dose alerted", len(pg.evaluate("window.__notes"))==n_before+1)
    pg.click("#dueSheet >> text=Later"); ok("later closes sheet", not pg.is_visible("#dueSheet"))
    ok("20:00 shows Due now", "Due now" in pg.inner_text("#todayList"))
    # low stock
    pg.evaluate("Almirah.state().items[0].qty=5; localStorage.setItem('almirah.v1',JSON.stringify(Almirah.state()))"); pg.click("button[data-tab=cabinet]"); pg.reload()
    # persistence of schedule + log
    ok("schedule persists", pg.evaluate("Almirah.state().items[0].schedule.times.length")==2)
    pg.click("button[data-tab=cabinet]")
    ok("cabinet shows reminder times", "⏰ 08:00, 20:00" in pg.inner_text("#list"))
    ok("low stock tag in cabinet (5 units, 2/day)", "day(s) of stock left" in pg.inner_text("#list"))
    # edit loads schedule
    pg.click("#list >> text=Edit"); ok("edit loads reminder", pg.is_checked("#fRemOn") and pg.locator("#timeList .tag").count()==2 and not pg.is_checked("#day0"))
    # turn off reminder
    pg.uncheck("#fRemOn"); pg.click("#btnSave"); ok("reminder cleared", pg.evaluate("Almirah.state().items[0].schedule")is None)
    # import sanitisation
    ok("cleanSchedule rejects bad", pg.evaluate("Almirah.cleanSchedule({times:['25:00','8:00']})") is None)
    # test reminder button
    pg.click("button[data-tab=more]"); pg.click("#btnTestRem"); pg.clock.run_for(5200)
    ok("test reminder notification", any("Test medicine" in (n[1] or "") for n in pg.evaluate("window.__notes")))
    pg.click("button[data-tab=today]"); pg.screenshot(path="/tmp/claude-0/-home-claude/f01ba4a4-fe36-5795-ba8e-16efdbbbafb5/scratchpad/today.png")
    b.close()
print("errors:",errs)
