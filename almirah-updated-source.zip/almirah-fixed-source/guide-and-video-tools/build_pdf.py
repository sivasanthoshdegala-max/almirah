import re,base64,subprocess
from playwright.sync_api import sync_playwright
h=open("/home/claude/explainer/guide.html",encoding="utf-8").read()
def uri(m):
    n=m.group(1); p=f"/home/claude/explainer/shots/{n}.png"
    return "data:image/png;base64,"+base64.b64encode(open(p,"rb").read()).decode()
h=re.sub(r"\{\{(\w+)\}\}",uri,h)
open("/home/claude/explainer/guide_inlined.html","w",encoding="utf-8").write(h)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(); pg.goto("file:///home/claude/explainer/guide_inlined.html"); pg.wait_for_timeout(500)
    pg.pdf(path="/home/claude/explainer/almirah-product-guide.pdf",prefer_css_page_size=True,print_background=True)
    # overflow check per page
    r=pg.evaluate("""[...document.querySelectorAll('.page')].map((p,i)=>{let max=0;p.querySelectorAll('*').forEach(e=>{const b=e.getBoundingClientRect();const pb=p.getBoundingClientRect();if(e.closest('.foot'))return;max=Math.max(max,b.bottom-pb.top)});return [i+1,Math.round(max),Math.round(p.getBoundingClientRect().height)]})""")
    print("page, content-bottom px, page px (foot starts ~ page-45):"); [print(x) for x in r]
    b.close()
