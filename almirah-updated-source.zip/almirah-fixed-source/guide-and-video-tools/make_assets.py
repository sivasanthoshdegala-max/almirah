import subprocess
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":640,"height":480}); pg.goto("file:///home/claude/explainer/assets/strip.html"); pg.screenshot(path="/home/claude/explainer/assets/strip.png"); b.close()
subprocess.run("ffmpeg -y -loglevel error -loop 1 -framerate 10 -i assets/strip.png -t 6 -vf scale=640:480,format=yuv420p assets/strip.y4m",shell=True,check=True,cwd="/home/claude/explainer")
print("ok")
