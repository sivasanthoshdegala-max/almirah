import json, datetime, sys
from playwright.sync_api import sync_playwright
IST=datetime.timezone(datetime.timedelta(hours=5,minutes=30))
T0=datetime.datetime(2026,10,14,7,58,0,tzinfo=IST)
def it(i,name,strength,form,qty,exp,owner,storage="cool_dry",sched=None,notes=""):
    return {"id":i,"name":name,"strength":strength,"form":form,"qty":qty,"expiry":exp,"owner":owner,"storage":storage,"batch":"","barcode":"","notes":notes,"addedAt":1760000000000+len(i),"schedule":sched}
two={"times":["08:00","20:00"],"days":[0,1,2,3,4,5,6],"perDose":1}
one={"times":["09:00"],"days":[0,1,2,3,4,5,6],"perDose":1}
SEED={"items":[
 it("a1","Calcium + D3","500 mg","tablet",7,"2027-09","Amma","cool_dry",two),
 it("a2","Vitamin B12","1500 mcg","capsule",30,"2027-03","Nanna","cool_dry",one),
 it("a3","Paracetamol","500 mg","tablet",10,"2027-07","Amma"),
 it("a4","Cetirizine","10 mg","tablet",6,"2026-10","Ravi"),
 it("a5","Cetirizine","10 mg","tablet",10,"2027-05","Ravi"),
 it("a6","ORS sachets","","other",4,"2028-01","Me","label"),
 it("a7","Cough syrup","","syrup",1,"2026-03","Me","below25"),
],"owners":["Me","Amma","Nanna","Ravi"],"barcodes":{"08901234500011":{"name":"Cetirizine","strength":"10 mg","form":"tablet","storage":"cool_dry"}},
"doseLog":{},"alerted":{},"snooze":{},"settings":{"remindDays":30,"lang":"en","notifiedOn":""}}
INIT="""if(!localStorage.getItem('almirah.v1')) localStorage.setItem('almirah.v1', %s);
window.Notification=function(t,o){this.close=()=>{}};Notification.permission='granted';Notification.requestPermission=()=>Promise.resolve('granted');""" % json.dumps(json.dumps(SEED))
ARGS=["--use-fake-ui-for-media-stream","--use-fake-device-for-media-stream","--use-file-for-fake-video-capture=/home/claude/explainer/assets/strip.y4m"]
URL="file:///home/claude/explainer/../almirah-app/index.html"
MODE=sys.argv[1]
with sync_playwright() as p:
    b=p.chromium.launch(args=ARGS)
    kw=dict(viewport={"width":390,"height":800},device_scale_factor=2,timezone_id="Asia/Kolkata",permissions=["camera"],locale="en-IN")
    if MODE=="video": kw=dict(viewport={"width":585,"height":1200},timezone_id="Asia/Kolkata",permissions=["camera"],locale="en-IN",record_video_dir="/home/claude/explainer/vid",record_video_size={"width":585,"height":1200})
    ctx=b.new_context(**kw); pg=ctx.new_page(); pg.add_init_script(INIT); pg.on("pageerror",lambda e:print("PAGEERR",e))
    pg.clock.install(time=T0); pg.goto(URL); pg.wait_for_timeout(300)
    if MODE=="video": pg.evaluate("document.documentElement.style.zoom='1.5'")
    def shot(n): pg.screenshot(path=f"/home/claude/explainer/shots/{n}.png")
    def cap(txt,sec=2.5):
        pg.evaluate("""t=>{let d=document.getElementById('__cap');if(!d){d=document.createElement('div');d.id='__cap';d.style.cssText='position:fixed;left:0;right:0;top:0;z-index:99999;background:rgba(10,106,95,.96);color:#fff;padding:10px 14px;font:600 15px system-ui;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.3)';document.body.appendChild(d)}d.textContent=t}""",txt)
        pg.wait_for_timeout(int(sec*1000))
    V = MODE=="video"
    hide=lambda: (pg.evaluate("(()=>{const t=document.getElementById('toast');t.style.transition='none';t.classList.remove('on');t.style.opacity=0})()"), pg.wait_for_timeout(120))
    def step(name,text,sec=2.5):
        hide()
        if V: cap(text,sec)
        else: shot(name)
    # 1 today upcoming
    step("s01_today_upcoming","Today tab: every dose of the day, in order",3)
    # 2 due popup
    pg.clock.run_for(3*60*1000); pg.wait_for_timeout(400)
    step("s02_due_popup","At dose time: popup + beep + notification",3)
    if V:
        pg.click("#dueSheet >> text=Snooze 10 min"); cap("Snooze 10 minutes",2)
        pg.clock.run_for(11*60*1000); pg.wait_for_timeout(400); cap("The reminder comes back after 10 minutes",2.5)
    pg.click("#dueSheet >> text=Taken"); pg.wait_for_timeout(500)
    step("s03_today_taken","Tap Taken: marked done, stock goes 7 to 6",3)
    # 4 cabinet
    pg.click("button[data-tab=cabinet]"); pg.wait_for_timeout(300)
    step("s04_cabinet","Cabinet: first-to-expire on top, duplicates flagged",3)
    if V: pg.mouse.wheel(0,500); pg.wait_for_timeout(1200)
    # 5 add form
    pg.click("button[data-tab=add]"); pg.wait_for_timeout(300)
    step("s05_add_top","Add a medicine by typing or scanning",2.5)
    # 7 scan overlay (live camera view, fake pack)
    pg.click("#btnOcr"); pg.wait_for_timeout(1800)
    step("s07_scan","Scan: point the camera at the pack (label reading)",3.5)
    pg.click("#scanClose"); pg.wait_for_timeout(300)
    # 8 scan result via GS1 pack code
    pg.evaluate("Almirah.handleCode('(01)08901234500011(17)271031(10)CT4521','add')"); pg.wait_for_timeout(400); pg.evaluate("window.scrollTo(0,0)")
    step("s08_scan_result","Scan fills the form. You review and save.",3.5)
    # 6 reminder section on new form
    pg.evaluate("document.getElementById('fRemOn').scrollIntoView({block:'center'})")
    pg.check("#fRemOn"); pg.click("#remBox .chip[data-t='08:00']"); pg.click("#remBox .chip[data-t='21:00']"); pg.wait_for_timeout(300)
    pg.evaluate("document.getElementById('fRemOn').scrollIntoView({block:'start'})"); pg.evaluate("window.scrollBy(0,-90)")
    step("s06_add_reminder","Turn on reminders: pick times and days",3.5)
    pg.click("#btnCancel"); pg.wait_for_timeout(200)
    # 9 buy check
    pg.click("button[data-tab=buy]")
    if V: pg.type("#buyQ","cetirizine",delay=140)
    else: pg.fill("#buyQ","cetirizine")
    pg.wait_for_timeout(300)
    step("s09_buy","Before you buy: is it already at home?",3.5)
    # 10 more
    pg.click("button[data-tab=more]"); pg.wait_for_timeout(300)
    step("s10_more","More: reminders, family members, backup, safe disposal",3)
    ctx.close(); b.close()
print("done",MODE)
