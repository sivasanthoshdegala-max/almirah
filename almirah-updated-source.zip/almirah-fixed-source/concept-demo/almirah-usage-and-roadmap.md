# Almirah – Usage Guide & Roadmap

## 1. Files em unnayi

| File | Purpose |
|---|---|
| `almirah-demo.html` | Full code of the 62-second concept demo (single file, no install) |
| `almirah-debug-source.html` | Same demo + debug panel + self-tests (bug fix cheyadaniki) |
| `almirah-usage-and-roadmap.md` | Ee guide: yela use cheyali + inka em add cheyochu |

> Note: ee demo oka **concept prototype**. Scan, inventory, reminders, languages, family – anni illustrative (sample data). Real service kaadu.

## 2. Demo ni yela use cheyali

1. `almirah-demo.html` ni double-click chesi Chrome/Edge lo open cheyandi (internet avasaram ledu).
2. Controls:
   - **▶ / ⏸** – play / pause (Space key kuda work avutundi)
   - **Timeline slider** – drag chesi scrub cheyochu
   - **Chapter buttons** – 6 scenes ki direct jump (Scan, Cabinet, Storage, Buy check, Languages, Care)
   - **← / →** keys – 5 seconds back / forward
3. Presentation lo: full-screen (F11) lo open chesi, scene by scene chapters tho explain cheyandi. Startup scheme judges ki "problem → idea" story ga baaga work avutundi.
4. Share cheyadaniki: GitHub Pages / Netlify Drop / Vercel lo ee single HTML file upload chesthe link vastundi.

## 3. Content ni edit cheyadam

- **Scene timings**: `SCENES` array lo `start` / `end` (seconds). `DURATION` = last scene end.
- **Elements appear time**: HTML lo `data-at="3"` ante scene start nundi 3 seconds taruvata kanipistundi.
- **Sample data**: medicine names, dates, owners direct ga HTML lo change cheyandi.
- **Languages**: Scene 5 lo `.lang` rows. Kotha language add cheyalante oka `<div class="lang" data-at="...">` add cheyandi.
- **Colors**: `:root` lo CSS variables (`--brand`, `--warn`, ...).

## 4. Bug fix cheyadam (debug build)

1. `almirah-debug-source.html` open cheyandi – kinda-right lo dark **debug panel** untundi.
2. **Run self-tests** click cheyandi. Idi check chestundi:
   - scenes gaps/overlaps lekunda continuous ga unnaya
   - slider max = DURATION na
   - seek 0 kante takkuva / 62 kante ekkuva clamp avutunda, invalid input ignore avutunda
   - prathi scene start lo okate scene active ga undha
   - `data-at` times scene length lo fit avutunda
   - scrub back chesthe elements malli hide avutunda
3. **Step +1s** – pause chesi okko second move avutu elements check cheyochu.
4. Errors anni panel lo red color lo kanipistayi (browser console kuda open cheyandi: F12).
5. Fix chesaka same change ni `almirah-demo.html` lo kuda apply cheyandi (debug file = demo + panel matrame).

### Common issues & fixes

| Problem | Reason | Fix |
|---|---|---|
| Telugu/Tamil text boxes ga kanipistundi | Device lo font ledu | Google Fonts "Noto Sans Telugu" etc. `<link>` add cheyandi |
| Mobile lo content cut avutundi | Fixed stage height | `@media (max-width:640px)` lo `.stage{height:...}` penchandi |
| Play after tab switch lo jump | Time delta big | Already `dt` clamp + auto-pause on hidden tab undi |
| Scene lo element kanipinchadam ledu | `data-at` > scene length | Debug test fail chupistundi |
| Slider drag chesthe stutter | Playing lo seek | `seekTo` lo `state.last` reset avutundi (already handled) |

## 5. Inka em add cheyochu (Roadmap)

PDF lo cheppina build sequence follow avudam:

### Phase 1 – Real inventory (first)
- Manual entry form: name, strength, quantity, expiry, owner
- Local save (`localStorage`/IndexedDB) → tarvata account + cloud DB (Firebase/Supabase)
- Review step: user confirm chesaka matrame save
- Duplicate detection: same name + strength match, expiry compare

### Phase 2 – Before-you-buy check + reminders
- Search box: "Paracetamol 500" → home lo undha, in-date na
- Expiry reminders (30/60 days), monthly stock check
- Mistakes correct cheyadaniki edit/delete

### Phase 3 – Scan & data
- Barcode/QR scan (browser `BarcodeDetector` or ZXing library)
- OCR for strip/box label (Tesseract.js / cloud OCR) – eppudu user review tho
- Verified medicine database source (licensed / government dataset) – guess cheyakudadu

### Phase 4 – Language & family
- Full UI translation: Telugu, Hindi, Tamil, Kannada, Malayalam (native speaker review tho)
- Family sharing with consent, roles (owner/helper), privacy controls
- Large text, high contrast, voice read-out (accessibility)

### Phase 5 – Before launch
- Privacy policy, consent, data encryption, secure login (OTP)
- Local disposal / take-back guidance (state-wise verified)
- Disclaimer: inventory tool, medical advice kaadu

### Mee Rxconflict idea tho connect cheyadam
Almirah (shelf inventory) + Rxconflict (prescription scan, interactions, side effects) combine chesthe strong product avutundi: "home lo em undi + avi kalipi teesukovacha?" Kani interaction/medical content ki Pharm.D reviewed, licensed data source must – inventory app lo medical advice ivvakudadu anna PDF principle gurthupettukondi.

## 6. Tech stack suggestion (student-friendly)

- **Prototype → App**: React/Next.js PWA (web + phone lo install) → later React Native/Flutter
- **Backend**: Supabase or Firebase (auth + DB + notifications)
- **OCR/Barcode**: ZXing, Tesseract.js
- **Hosting**: Vercel/Netlify (free tier)

## 7. Startup scheme (India) kosam tips

- Problem statement clear ga: "Households repeat-buy medicines, expired medicines store chestaru"
- Demo + 10–20 households tho small survey/pilot data
- Pharm.D student advantage hype cheyandi: pharmacist review, safety-first design
- Check: Startup India, state startup missions (e.g., AP Innovation Society), college incubation cells, NIDHI-PRAYAS style programs – eligibility ni official sites lo confirm cheskondi
- Privacy & medical-claim compliance mundu plan cheyandi

*All medicine names, dates, people and pharmacies in the demo are illustrative. Not medical advice.*
