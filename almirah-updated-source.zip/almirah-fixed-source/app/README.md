# Almirah – Home Medicine Inventory (v1.1)

Single-file app. No build, no install.

## Run
- Laptop: open `index.html` in Chrome/Edge.
- Camera / notifications work best on HTTPS or localhost:
      python3 -m http.server 8000     then open http://localhost:8000
- Phone: upload the folder to Netlify Drop / GitHub Pages / Vercel, open the https link,
  then "Add to Home screen".

## Dose-time reminders (new)
1. Add or Edit a medicine > turn on "Remind me to take this".
2. Pick times (Morning 08:00 / Afternoon 14:00 / Night 21:00 or any custom time), days of week, units per dose.
3. At each time: a popup with Taken / Snooze 10 min / Skip, a beep, vibration, and a notification (if allowed).
4. "Today" tab lists every dose: Upcoming, Due now, Missed (after 2 h), Taken, Skipped. Undo is available.
5. "Taken" lowers the stock by units-per-dose; "Running low" shows when about 3 days or less remain.
6. More > "Send test reminder" checks sound and notifications in 5 seconds.

IMPORTANT LIMITS
- Reminders ring only while Almirah is open (screen on, or app in a background tab).
  Browsers pause closed pages, so keep it open ("Keep screen on" button) and use a phone alarm as backup.
- Doses older than 3 hours are not alerted, they appear as Missed in Today.
- For alarms that ring when the app is closed you need an Android app (Flutter/React Native local alarms)
  or a push-notification server. That is the next build step.
- The schedule is what the user enters from their doctor/pharmacist. Almirah never suggests doses.

## Scanning
- Scan barcode / QR: live camera; GS1 pack codes fill expiry + batch + GTIN
- Read label: Tesseract.js OCR (needs internet once) reads the image twice (original and contrast-enhanced) to handle different label layouts and lighting
- From photo opens the image chooser; it does not force the camera
- OCR avoids filling a medicine name when the scan looks like obvious recognition noise, and ignores likely package weights such as "Net wt 4 g"
Scans only fill the form. Always review before saving.

## Notes
- Data is stored only in this browser (localStorage). Export a backup from More > Your data.
- Barcode lookup uses only packs you saved before; no medicine database is included.
- Telugu/Hindi translations are drafts; get native review before launch.
- Not medical advice; inventory helper only.
